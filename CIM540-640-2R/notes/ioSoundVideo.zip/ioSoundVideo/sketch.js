
function preload(){

}

function setup() {


}

function draw() {


}

function mousePressed(){

}
