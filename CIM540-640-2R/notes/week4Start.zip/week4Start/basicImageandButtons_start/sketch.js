/* "Up-Close Sloth" by marissa_strniste, "Baby sloth, being cute" by Dave Gingrich is licensed under CC BY-SA 2.0. To view a copy of this license, visit: https://creativecommons.org/licenses/by-sa/2.0*/


function preload(){

}

function setup() {
  // put setup code here

}

function draw() {
  // put drawing code here

}
